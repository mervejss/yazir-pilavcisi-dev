import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import { tl } from '@/lib/helpers';
import { SOURCE_COLORS, SOURCE_LABELS, SOURCE_EMOJI } from '@/lib/constants';
import Kpi from '@/components/ui/Kpi';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import AnalyticsCharts from '@/components/admin/AnalyticsCharts';

interface UnifiedOrder {
  id: string;
  platform: string;
  status: 'delivered' | 'cancelled';
  ordered_at: Date;
  total: number;
  district: string;
  payment_method: string;
  items: { name: string; qty: number }[];
}

const PLATFORMS = ['all', 'web', 'phone', 'table', 'counter', 'trendyol', 'yemeksepeti', 'getir', 'migros'];

export default function Analytics() {
  const [daysBack, setDaysBack] = useState<number>(30);
  const [loading, setLoading] = useState(true);
  const [platformFilter, setPlatformFilter] = useState<string>('all');
  const [estCommissionRate, setEstCommissionRate] = useState<number>(20);

  // Raw Data States
  const [rawOrders, setRawOrders] = useState<UnifiedOrder[]>([]);
  const [courierPerf, setCourierPerf] = useState<any[]>([]);
  const [tableUsage, setTableUsage] = useState<any[]>([]);
  const [timings, setTimings] = useState<any>(null);

  useEffect(() => {
    const fetchReports = async () => {
      setLoading(true);
      const to = new Date();
      const from = new Date(Date.now() - daysBack * 864e5);
      const p_from = from.toISOString();
      const p_to = to.toISOString();

      try {
        // 1. Canlı Sistem Siparişleri (orders tablosu)
        const lq = supabase.from('orders')
            .select('id, order_no, source, status, created_at, total, payment_method, district, pin_code, external_payload, order_items(product_name, quantity, unit_price)')
            .in('status', ['delivered', 'cancelled'])
            .gte('created_at', p_from)
            .lte('created_at', p_to);

        // 2. Excel'den Aktarılan Geçmiş Siparişler
        const iq = supabase.from('past_import_orders_v')
            .select('*')
            .gte('ordered_at', p_from.replace('T', ' ').slice(0, 19))
            .lte('ordered_at', p_to.replace('T', ' ').slice(0, 19));

        // 3. Yalnızca Canlı Sisteme Özel (Kurye & Masa & Süre) RPC'ler
        const courReq = supabase.rpc('report_courier_performance', { p_from, p_to });
        const tableReq = supabase.rpc('report_table_usage', { p_from, p_to });
        const timeReq = supabase.rpc('report_order_timings', { p_from, p_to });

        const [liveRes, impRes, courRes, tableRes, timeRes] = await Promise.all([lq, iq, courReq, tableReq, timeReq]);

        const liveNos = new Set<string>();
        const liveOrders: UnifiedOrder[] = (liveRes.data || []).map((o: any) => {
          if (o.pin_code) liveNos.add(String(o.pin_code));
          if (o.external_payload?.orderNumber) liveNos.add(String(o.external_payload.orderNumber));
          if (o.order_no) liveNos.add(String(o.order_no));

          return {
            id: String(o.id),
            platform: o.source || 'web',
            status: o.status === 'cancelled' ? 'cancelled' : 'delivered',
            ordered_at: new Date(o.created_at),
            total: Number(o.total) || 0,
            district: o.district || '',
            payment_method: o.payment_method || '',
            items: (o.order_items || []).map((i: any) => ({ name: i.product_name, qty: Number(i.quantity) || 1 }))
          };
        });

        const parseDate = (s: string) => new Date(s.includes('T') ? s : s.replace(' ', 'T'));
        const stateOfText = (t: string) => {
          const s = (t || '').toLocaleLowerCase('tr');
          if (s.includes('iptal') || s.includes('cancel') || s.includes('unsupplied')) return 'cancelled';
          return 'delivered';
        };

        const impOrders: UnifiedOrder[] = (impRes.data || [])
            .filter((o: any) => !liveNos.has(String(o.order_no))) // Mükerrer olanları çıkar
            .map((o: any) => ({
              id: `imp-${o.order_no}`,
              platform: o.platform || 'other',
              status: stateOfText(o.status),
              ordered_at: parseDate(o.ordered_at),
              total: Number(o.total) || 0,
              district: o.district || '',
              payment_method: o.payment_method || '',
              items: (o.items || []).map((i: any) => ({ name: i.name, qty: Number(i.qty) || 1 }))
            }));

        setRawOrders([...liveOrders, ...impOrders]);

        if (courRes.data) setCourierPerf(courRes.data as any[]);
        if (tableRes.data) setTableUsage(tableRes.data as any[]);
        if (timeRes.data && (timeRes.data as any)[0]) setTimings((timeRes.data as any)[0]);

      } catch (err) {
        console.error('Reports fetch error:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchReports();
  }, [daysBack]);

  // Yeni: Platform butonları için sipariş sayılarını hesapla (İptaller dahil tüm kayıtlı siparişler)
  const platformCounts = useMemo(() => {
    const counts: Record<string, number> = { all: rawOrders.length };
    rawOrders.forEach(o => {
      counts[o.platform] = (counts[o.platform] || 0) + 1;
    });
    return counts;
  }, [rawOrders]);

  // Filtrelemeler ve Hesaplamalar (Platform Değiştiğinde Anında Hesaplanır)
  const { summary, daily, topProducts, bySource, districts, payments } = useMemo(() => {
    const filtered = platformFilter === 'all' ? rawOrders : rawOrders.filter(o => o.platform === platformFilter);

    let delivered_count = 0;
    let cancelled_count = 0;
    let revenue = 0;
    const hourCounts: Record<number, number> = {};
    const dMap: Record<string, { day: string; order_count: number; revenue: number }> = {};
    const pMap: Record<string, number> = {};
    const sMap: Record<string, { order_count: number; revenue: number }> = {};
    const distMap: Record<string, number> = {};
    const payMap: Record<string, number> = {};

    const pad = (n: number) => String(n).padStart(2, '0');

    filtered.forEach(o => {
      // Özet
      if (o.status === 'cancelled') {
        cancelled_count++;
      } else {
        delivered_count++;
        revenue += o.total;
      }

      const h = o.ordered_at.getHours();
      hourCounts[h] = (hourCounts[h] || 0) + 1;

      // Günlük
      const day = `${o.ordered_at.getFullYear()}-${pad(o.ordered_at.getMonth() + 1)}-${pad(o.ordered_at.getDate())}`;
      if (!dMap[day]) dMap[day] = { day, order_count: 0, revenue: 0 };
      dMap[day].order_count++;
      if (o.status !== 'cancelled') dMap[day].revenue += o.total;

      // Ürünler, Kaynak, İlçe, Ödeme (Sadece başarılı siparişlerden)
      if (o.status !== 'cancelled') {
        o.items.forEach(i => { pMap[i.name] = (pMap[i.name] || 0) + i.qty; });

        if (!sMap[o.platform]) sMap[o.platform] = { order_count: 0, revenue: 0 };
        sMap[o.platform].order_count++;
        sMap[o.platform].revenue += o.total;

        const dist = o.district || 'Belirtilmemiş';
        distMap[dist] = (distMap[dist] || 0) + 1;

        const pay = o.payment_method || 'Belirtilmemiş';
        payMap[pay] = (payMap[pay] || 0) + 1;
      }
    });

    let peak_hour = 13;
    let maxH = 0;
    Object.entries(hourCounts).forEach(([h, c]) => { if (c > maxH) { maxH = c; peak_hour = Number(h); } });

    return {
      summary: {
        order_count: filtered.length,
        delivered_count,
        cancelled_count,
        revenue,
        avg_basket: delivered_count > 0 ? revenue / delivered_count : 0,
        peak_hour: maxH > 0 ? peak_hour : null
      },
      daily: Object.values(dMap).sort((a, b) => a.day.localeCompare(b.day)),
      topProducts: Object.entries(pMap).map(([product_name, quantity]) => ({ product_name, quantity })).sort((a, b) => b.quantity - a.quantity).slice(0, 10),
      bySource: Object.entries(sMap).map(([source, stats]) => ({ source, label: SOURCE_LABELS[source] || source, is_platform: ['trendyol', 'yemeksepeti', 'getir', 'migros'].includes(source), ...stats })).sort((a, b) => b.order_count - a.order_count),
      districts: Object.entries(distMap).map(([district, order_count]) => ({ district, order_count })).sort((a, b) => b.order_count - a.order_count).slice(0, 10),
      payments: Object.entries(payMap).map(([payment_method, order_count]) => ({ payment_method, order_count })).sort((a, b) => b.order_count - a.order_count).slice(0, 7)
    };
  }, [rawOrders, platformFilter]);

  if (loading) return <LoadingSpinner text="Raporlar ve analizler birleştiriliyor..." />;

  const maxDaily = Math.max(1, ...daily.map((d) => d.order_count));
  const maxProd = Math.max(1, ...topProducts.map((p) => p.quantity));
  const maxDist = Math.max(1, ...districts.map((d) => d.order_count));

  const platformRevenue = bySource.filter((s) => s.is_platform).reduce((sum, s) => sum + s.revenue, 0);
  const ownRevenue = bySource.filter((s) => !s.is_platform).reduce((sum, s) => sum + s.revenue, 0);
  const savedCommission = (ownRevenue * estCommissionRate) / 100;

  return (
      <>
        <div className="bar" style={{ flexWrap: 'wrap' }}>
          <div>
            <h1>Raporlar ve İşletme Analizi</h1>
            <p className="muted" style={{ margin: 0 }}>
              Canlı siparişler ve geçmiş Excel kayıtlarının birleştirilmiş analizleri
            </p>
          </div>
          <div className="seg">
            <button type="button" className={daysBack === 7 ? 'on' : ''} onClick={() => setDaysBack(7)}>Son 7 Gün</button>
            <button type="button" className={daysBack === 30 ? 'on' : ''} onClick={() => setDaysBack(30)}>Son 30 Gün</button>
            <button type="button" className={daysBack === 90 ? 'on' : ''} onClick={() => setDaysBack(90)}>Son 3 Ay</button>
          </div>
        </div>

        <div className="src-filter" style={{ marginBottom: '1.5rem', display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
          {PLATFORMS.map(p => (
              <button
                  key={p}
                  type="button"
                  className={platformFilter === p ? 'on' : ''}
                  onClick={() => setPlatformFilter(p)}
              >
                {p === 'all' ? 'Tüm Platformlar' : `${SOURCE_EMOJI[p] || '•'} ${SOURCE_LABELS[p] || p}`}
                {/* Sayacı Göster */}
                <i style={{ marginLeft: '6px', fontSize: '0.85em', opacity: 0.7 }}>
                  ({platformCounts[p] || 0})
                </i>
              </button>
          ))}
        </div>

        <AnalyticsCharts platformFilter={platformFilter} />
        <div className="kpis">
          <Kpi label="Toplam Sipariş" value={summary.order_count || 0} />
          <Kpi label="Toplam Ciro (Teslim)" value={tl(summary.revenue || 0)} />
          <Kpi label="Ortalama Sepet" value={tl(summary.avg_basket || 0)} />
          <Kpi
              label="En Yoğun Saat"
              value={summary.peak_hour != null ? `${String(summary.peak_hour).padStart(2, '0')}:00` : '—'}
          />
        </div>

        {/* Ortalama Süreler (Yalnızca Canlı Sistem) */}
        {timings && platformFilter === 'all' && (
            <div className="card">
              <h3>Ortalama Sipariş ve Teslimat Süreleri (Kurye / Kendi Ağınız)</h3>
              <div className="kpis" style={{ margin: 0 }}>
                <Kpi label="Hazırlama Süresi" value={`${timings.avg_prepare_min || 0} dk`} />
                <Kpi label="Kurye Bekleme" value={`${timings.avg_wait_courier_min || 0} dk`} />
                <Kpi label="Yolda Geçen Süre" value={`${timings.avg_delivery_min || 0} dk`} />
                <Kpi label="Toplam Teslimat" value={`${timings.avg_total_min || 0} dk`} />
              </div>
            </div>
        )}

        {/* Günlük Sipariş Grafiği */}
        <div className="card">
          <h3>Günlük Sipariş Dağılımı ({platformFilter === 'all' ? 'Tümü' : SOURCE_LABELS[platformFilter]})</h3>
          <div className="bars">
            {daily.map((x, i) => (
                <div key={i} className="b" title={`${x.day}: ${x.order_count} sipariş, ${tl(x.revenue)}`}>
                  <i style={{ height: `${(x.order_count / maxDaily) * 100}%` }} />
                </div>
            ))}
            {daily.length === 0 && <p className="muted small">Grafik için veri yok.</p>}
          </div>
        </div>

        <div className="three">
          {/* En Çok Satan Ürünler */}
          <div className="card">
            <h3>En Çok Satan Ürünler</h3>
            {topProducts.map((p, i) => (
                <div key={i} className="hbar">
                  <span>{p.product_name}</span>
                  <i style={{ width: `${(p.quantity / maxProd) * 100}%` }} />
                  <b>{p.quantity}</b>
                </div>
            ))}
            {topProducts.length === 0 && <p className="muted small">Kayıt bulunamadı.</p>}
          </div>

          {/* Mahalleye Göre Dağılım */}
          <div className="card">
            <h3>Mahalleye Göre Dağılım</h3>
            {districts.map((d, i) => (
                <div key={i} className="hbar">
                  <span>{d.district}</span>
                  <i style={{ width: `${(d.order_count / maxDist) * 100}%` }} />
                  <b>{d.order_count}</b>
                </div>
            ))}
            {districts.length === 0 && <p className="muted small">Kayıt bulunamadı.</p>}
          </div>

          {/* Ödeme Yöntemleri */}
          <div className="card">
            <h3>Ödeme Yöntemleri</h3>
            {payments.map((p, i) => (
                <div key={i} className="hbar">
                  <span>{p.payment_method}</span>
                  <i style={{ width: '60%' }} />
                  <b>{p.order_count}</b>
                </div>
            ))}
            {payments.length === 0 && <p className="muted small">Kayıt bulunamadı.</p>}
          </div>
        </div>

        {/* Sipariş Kaynakları & Komisyon Analizi */}
        <div className="card">
          <h3>Sipariş Kaynakları ve Komisyon Tasarruf Analizi</h3>
          <div style={{ margin: '1rem 0' }}>
            {bySource.map((s) => (
                <div key={s.source} className="hbar">
                  <span>{s.label}</span>
                  <i
                      style={{
                        width: `${(s.order_count / Math.max(1, summary.order_count)) * 100}%`,
                        background: SOURCE_COLORS[s.source.toLowerCase()] || '#6b6556',
                      }}
                  />
                  <b>{s.order_count}</b>
                </div>
            ))}
          </div>
          <div className="note" style={{ marginTop: '1rem' }}>
            Platform Cirosu: <b>{tl(platformRevenue)}</b> · Doğrudan (Web/Telefon/Masa) Ciro:{' '}
            <b>{tl(ownRevenue)}</b>
            <br />
            Tahmini Platform Komisyon Oranı: %
            <input
                type="number"
                className="rate"
                value={estCommissionRate}
                onChange={(e) => setEstCommissionRate(Number(e.target.value))}
            />{' '}
            ile kendi sisteminiz sayesinde yaklaşık <b>{tl(savedCommission)}</b> komisyon
            ödemekten kurtuldunuz!
          </div>
        </div>

        {/* Kurye ve Masa (Yalnızca canlı sistem) */}
        {platformFilter === 'all' && (
            <>
              <div className="card">
                <h3>Kurye Performans Tablosu</h3>
                <table className="tbl">
                  <thead>
                  <tr>
                    <th>Kurye Adı</th>
                    <th>Teslimat Adedi</th>
                    <th>Taşıdığı Ciro</th>
                    <th>Ort. Toplam Süre</th>
                    <th>Ort. Teslim Süresi</th>
                  </tr>
                  </thead>
                  <tbody>
                  {courierPerf.map((c) => (
                      <tr key={c.courier_id}>
                        <td><b>{c.courier_name}</b></td>
                        <td>{c.delivery_count} paket</td>
                        <td>{tl(c.revenue_carried)}</td>
                        <td>{c.avg_total_minutes || '—'} dk</td>
                        <td>{c.avg_delivery_minutes || '—'} dk</td>
                      </tr>
                  ))}
                  {courierPerf.length === 0 && <tr><td colSpan={5} className="center muted">Bu dönemde teslimat kaydı bulunmuyor.</td></tr>}
                  </tbody>
                </table>
              </div>

              <div className="card">
                <h3>Masa Kullanım İstatistikleri</h3>
                <table className="tbl">
                  <thead>
                  <tr>
                    <th>Masa</th>
                    <th>Oturum Sayısı</th>
                    <th>Toplam Sipariş</th>
                    <th>Üretilen Ciro</th>
                    <th>Ort. Oturum Süresi</th>
                  </tr>
                  </thead>
                  <tbody>
                  {tableUsage.map((t) => (
                      <tr key={t.table_id}>
                        <td><b>Masa {t.table_number}</b></td>
                        <td>{t.session_count} kez</td>
                        <td>{t.order_count}</td>
                        <td>{tl(t.revenue)}</td>
                        <td>{t.avg_session_minutes || 0} dk</td>
                      </tr>
                  ))}
                  {tableUsage.length === 0 && <tr><td colSpan={5} className="center muted">Bu dönemde masa kullanım kaydı bulunmuyor.</td></tr>}
                  </tbody>
                </table>
              </div>
            </>
        )}
      </>
  );
}
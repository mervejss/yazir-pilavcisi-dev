import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { DAY_NAMES } from '@/lib/constants';
import type { BusinessSettings, OpeningHour } from '@/types/database';

export const SITE_URL = 'https://yazirpilavcisi.com.tr';
const OG_IMAGE = `${SITE_URL}/logo.png`;

const PAGES: Record<string, { title: string; desc: string; noindex?: boolean }> = {
  '/': { title: 'Yazır Pilavcısı | Konya Yazır Online Pilav Siparişi', desc: 'Konya Yazır\'da tane tane pilav, tavuk, et ve körili pilav. Online sipariş verin, kendi kuryelerimizle sıcak sıcak 15 dakikada kapınıza getirelim. Gece 03:00\'e kadar açığız.' },
  '/menu': { title: 'Menü | Yazır Pilavcısı Konya', desc: 'Yazır Pilavcısı menüsü: tavuk pilav, et pilav, körili pilav, kuru fasulye, içecekler ve daha fazlası. Fiyatları görün, hemen sipariş verin.' },
  '/siparis': { title: 'Online Sipariş Ver | Yazır Pilavcısı', desc: 'Yazır Pilavcısı\'ndan online paket servis, gel-al siparişi verin. Kapıda nakit, kart veya IBAN ile ödeme.' },
  '/kampanyalar': { title: 'Kampanyalar ve Kupon Kodları | Yazır Pilavcısı', desc: 'Yazır Pilavcısı güncel kampanyalar ve indirim kuponları.' },
  '/toplu': { title: 'Toplu Yemek Siparişi — Cenaze, Mevlit, Özel Gün | Yazır Pilavcısı', desc: 'Cenaze, mevlit, düğün ve özel günler için Konya\'da toplu pilav ve yemek siparişi. Kişi sayısını yazın, sizi arayalım.' },
  '/galeri': { title: 'Galeri | Yazır Pilavcısı', desc: 'Yazır Pilavcısı restoranı ve yemeklerinden fotoğraflar.' },
  '/yorumlar': { title: 'Müşteri Yorumları | Yazır Pilavcısı', desc: 'Müşterilerimizin Yazır Pilavcısı hakkındaki yorumları.' },
  '/iletisim': { title: 'İletişim ve Adres | Yazır Pilavcısı Konya', desc: 'Yazır Pilavcısı adres, telefon, WhatsApp, çalışma saatleri ve yol tarifi. Yazır mah. Selçuklu / Konya.' },
  '/giris': { title: 'Giriş Yap | Yazır Pilavcısı', desc: 'Hesabınıza giriş yapın.', noindex: true },
  '/kayit': { title: 'Kayıt Ol | Yazır Pilavcısı', desc: 'Yeni hesap oluşturun.', noindex: true },
  '/profil': { title: 'Profilim | Yazır Pilavcısı', desc: 'Hesabım.', noindex: true },
  '/personel-giris': { title: 'Personel Girişi', desc: 'Personel girişi.', noindex: true },
};

function setMeta(sel: string, attr: 'name' | 'property', key: string, value: string) {
  let el = document.head.querySelector<HTMLMetaElement>(sel);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute('content', value);
}

/** Sayfa başına title / description / canonical / OG + Restaurant JSON-LD */
export default function Seo({ settings, hours }: { settings: BusinessSettings | null; hours: OpeningHour[] }) {
  const { pathname } = useLocation();

  useEffect(() => {
    const key = pathname.replace(/\/+$/, '') || '/';
    const base = '/' + key.split('/')[1];
    const page = PAGES[key] || PAGES[base === '/' ? '/' : base] || (key.startsWith('/takip') || key.startsWith('/qr') ? { title: 'Sipariş Takibi | Yazır Pilavcısı', desc: 'Siparişinizi takip edin.', noindex: true } : PAGES['/']);
    const url = SITE_URL + (key === '/' ? '/' : key);
    document.title = page.title;
    setMeta('meta[name="description"]', 'name', 'description', page.desc);
    setMeta('meta[name="robots"]', 'name', 'robots', page.noindex ? 'noindex,nofollow' : 'index,follow,max-image-preview:large');
    setMeta('meta[property="og:title"]', 'property', 'og:title', page.title);
    setMeta('meta[property="og:description"]', 'property', 'og:description', page.desc);
    setMeta('meta[property="og:url"]', 'property', 'og:url', url);
    setMeta('meta[property="og:image"]', 'property', 'og:image', OG_IMAGE);
    setMeta('meta[name="twitter:title"]', 'name', 'twitter:title', page.title);
    setMeta('meta[name="twitter:description"]', 'name', 'twitter:description', page.desc);
    let link = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!link) {
      link = document.createElement('link');
      link.rel = 'canonical';
      document.head.appendChild(link);
    }
    link.href = url;
  }, [pathname]);

  useEffect(() => {
    if (!settings) return;
    const specs = hours
      .filter((h) => !h.is_closed)
      .map((h) => ({
        '@type': 'OpeningHoursSpecification',
        dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'][h.day_of_week - 1] || DAY_NAMES[h.day_of_week - 1],
        opens: h.open_time.slice(0, 5),
        closes: h.close_time.slice(0, 5),
      }));
    const tel = (settings.phone || '0540 331 41 42').replace(/\s/g, '').replace(/^0/, '+90');
    const data: Record<string, unknown> = {
      '@context': 'https://schema.org',
      '@type': 'Restaurant',
      '@id': SITE_URL + '/#restaurant',
      name: settings.name || 'Yazır Pilavcısı',
      url: SITE_URL + '/',
      image: OG_IMAGE,
      logo: OG_IMAGE,
      telephone: tel,
      servesCuisine: ['Pilav', 'Türk mutfağı'],
      priceRange: '₺₺',
      hasMenu: SITE_URL + '/menu',
      acceptsReservations: false,
      address: { '@type': 'PostalAddress', streetAddress: settings.address || 'Yazır mah. Şehit Erkan Özbalcı sk. 20/b', addressLocality: 'Selçuklu', addressRegion: 'Konya', addressCountry: 'TR' },
      sameAs: [settings.instagram_url, settings.google_maps_url].filter(Boolean),
    };
    if (settings.lat && settings.lng) data.geo = { '@type': 'GeoCoordinates', latitude: Number(settings.lat), longitude: Number(settings.lng) };
    if (specs.length) data.openingHoursSpecification = specs;
    let el = document.getElementById('ld-restaurant') as HTMLScriptElement | null;
    if (!el) {
      el = document.createElement('script');
      el.id = 'ld-restaurant';
      el.type = 'application/ld+json';
      document.head.appendChild(el);
    }
    el.textContent = JSON.stringify(data);
  }, [settings, hours]);

  return null;
}

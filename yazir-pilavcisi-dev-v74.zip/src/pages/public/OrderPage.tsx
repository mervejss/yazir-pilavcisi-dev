import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useCartStore } from '@/stores/cartStore';
import { useAuthStore } from '@/stores/authStore';
import { useCustomerAddresses } from '@/hooks/useCustomerAddresses';
import { useBusinessSettings } from '@/hooks/useBusinessSettings';
import { supabase } from '@/lib/supabase';
import { discountedPrice, slugify, tl } from '@/lib/helpers';
import { PAYMENT_METHOD_LABELS } from '@/lib/constants';
import QtyStepper from '@/components/ui/QtyStepper';
import ProductImage from '@/components/ui/ProductImage';
import Icon from '@/components/ui/Icon';
import DineInPicker from '@/components/public/DineInPicker';
import LocationPicker from '@/components/maps/LocationPicker';
import VoiceDictateButton from '@/components/ui/VoiceDictateButton';
import { normalizePhone } from '@/lib/staffCustomers';
import toast from 'react-hot-toast';
import { waUrl } from '@/lib/whatsapp';

interface OrderResult {
  order_id: string;
  order_no: number;
  total: number;
  status: string;
}

export default function OrderPage() {
  const { items, changeQty, removeItem, clearCart, total, tableToken } = useCartStore();
  const [selectedCartKeys, setSelectedCartKeys] = useState<string[]>([]);
  const { user, profile } = useAuthStore();
  const { addresses } = useCustomerAddresses();
  const { settings, status } = useBusinessSettings();
  // Sahip siparişi kapattıysa VEYA "çalışma saati dışında engelle" açıkken kapalıysak sipariş verilemez
  const orderBlocked = status.paused || (!!settings?.enforce_opening_hours && status.outsideHours);
  const cartTotal = total();

  // ---- Sipariş türü: Restoranda yiyeceğim / Eve sipariş (QR ile gelindiyse masa zaten belli) ----
  const [mode, setMode] = useState<'dine' | 'delivery' | null>(null);
  const dine = !!tableToken || mode === 'dine';
  const [tableNo, setTableNo] = useState<number | null>(null);
  const [seat, setSeat] = useState<number | null>(null);
  const [qrNo, setQrNo] = useState<number | null>(null);
  useEffect(() => {
    if (!tableToken) { setQrNo(null); return; }
    supabase.rpc('resolve_table_qr', { p_token: tableToken }).then(({ data }) => {
      const n = Number((data as any)?.table_number);
      setQrNo(Number.isFinite(n) && n > 0 ? n : null);
    });
  }, [tableToken]);
  const needTable = dine && !tableToken && tableNo == null;
  const selectedCartItems = items.filter((item) => selectedCartKeys.includes(item.key));
  useEffect(() => {
    setSelectedCartKeys((current) => current.filter((key) => items.some((item) => item.key === key)));
  }, [items]);
  const removeSelectedItems = () => {
    if (!selectedCartItems.length) return;
    selectedCartItems.forEach((item) => removeItem(item.key));
    setSelectedCartKeys([]);
    toast.success(`${selectedCartItems.length} sepet satırı kaldırıldı`);
  };
  const emptyCart = () => {
    if (!items.length || !window.confirm('Sepetinizdeki tüm ürünleri kaldırmak istiyor musunuz?')) return;
    clearCart();
    setSelectedCartKeys([]);
    toast.success('Sepetiniz temizlendi');
  };

  // ---- Kupon & sadakat puanı ----
  const [couponInput, setCouponInput] = useState('');
  const [coupon, setCoupon] = useState<{ code: string; discount: number; title: string } | null>(null);
  const [couponBusy, setCouponBusy] = useState(false);
  const [referral, setReferral] = useState<any>(null);
  const [loyalty, setLoyalty] = useState<any>(null);
  const [usePoints, setUsePoints] = useState(false);
  const deliveryFee = settings && !dine ? (settings.free_delivery_threshold && cartTotal >= settings.free_delivery_threshold ? 0 : settings.delivery_fee) : 0;
  const couponDiscount = coupon ? Math.min(coupon.discount, cartTotal + deliveryFee) : 0;
  const afterCoupon = Math.max(cartTotal + deliveryFee - couponDiscount, 0);
  const pointValue = Number(loyalty?.point_value || 1);
  const pointsAvail = Number(loyalty?.points || 0);
  const canUsePoints = !!loyalty?.enabled && !dine && !!user && pointsAvail >= Number(loyalty?.min_redeem || 1);
  const pointsToUse = canUsePoints && usePoints ? Math.min(pointsAvail, Math.ceil(afterCoupon / pointValue)) : 0;
  const pointsDiscount = pointsToUse ? Math.min(pointsToUse * pointValue, afterCoupon) : 0;
  const referralPercent = !dine && referral?.is_active ? Number(referral.discount || 0) : 0;
  const productReferral = referralPercent > 0 && referral?.scope === 'product';
  // Ürün bazlı kampanyada her birim fiyat, SQL tarafındaki numeric(…,2) ile aynı şekilde yuvarlanır.
  const referralDiscount = productReferral
    ? Math.round((items.reduce((sum, item) => sum + (item.price - discountedPrice(item.price, referralPercent)) * item.quantity, 0) + Number.EPSILON) * 100) / 100
    : referralPercent > 0 && referral?.scope === 'cart'
      ? Math.round((cartTotal * referralPercent / 100 + Number.EPSILON) * 100) / 100
      : 0;
  const grandTotal = Math.max(afterCoupon - pointsDiscount - referralDiscount, 0);

  useEffect(() => {
    if (!user) { setReferral(null); return; }
    const refreshReferral = () => supabase.rpc('my_referral').then(({ data, error }) => { if (!error) setReferral(data || null); });
    refreshReferral();
    const referralChannel = supabase.channel(`referral-order-${user.id}`).on('postgres_changes', { event: '*', schema: 'public', table: 'referral_campaigns' }, refreshReferral).subscribe();
    const referralTimer = window.setInterval(() => { if (document.visibilityState === 'visible') refreshReferral(); }, 180000);
    supabase.rpc('my_loyalty').then(({ data, error }) => {
      if (!error && data) setLoyalty(data);
    });
    return () => { window.clearInterval(referralTimer); supabase.removeChannel(referralChannel); };
  }, [user]);

  // Sepet değişince kupon tutarını yeniden doğrula
  useEffect(() => {
    if (!coupon) return;
    supabase
      .rpc('validate_coupon', { p_code: coupon.code, p_subtotal: cartTotal, p_phone: form.phone || null })
      .then(({ data }: any) => {
        if (data?.ok) setCoupon({ code: coupon.code, discount: Number(data.discount), title: data.title || '' });
        else {
          setCoupon(null);
          if (data?.error) toast.error(data.error);
        }
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cartTotal]);

  const applyCoupon = async () => {
    const code = couponInput.trim();
    if (!code) return;
    setCouponBusy(true);
    const { data, error } = await supabase.rpc('validate_coupon', { p_code: code, p_subtotal: cartTotal, p_phone: form.phone || null });
    setCouponBusy(false);
    if (error) return void toast.error('Kupon sistemi için 15_coupons_loyalty.sql dosyasının çalıştırılması gerekiyor');
    const r: any = data;
    if (!r?.ok) return void toast.error(r?.error || 'Kupon geçersiz');
    setCoupon({ code: code.toUpperCase(), discount: Number(r.discount), title: r.title || '' });
    toast.success(`Kupon uygulandı: −${tl(Number(r.discount))}`);
  };

  const [selectedAddrId, setSelectedAddrId] = useState<string>('custom');
  const [form, setForm] = useState({
    name: profile?.full_name || '',
    phone: profile?.phone || '',
    address: '',
    district: 'Yazır',
    note: '',
    payment: 'cash_on_delivery' as string,
    saveAddress: false,
    addressTitle: 'Ev',
  });
  const [loc, setLoc] = useState<[number, number] | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<OrderResult | null>(null);

  // Profile data sync
  useEffect(() => {
    if (profile) {
      setForm((f) => ({
        ...f,
        name: f.name || profile.full_name || '',
        phone: f.phone || profile.phone || '',
      }));
    }
  }, [profile]);

  // Set default address if available
  useEffect(() => {
    if (addresses.length > 0 && selectedAddrId === 'custom') {
      const def = addresses.find((a) => a.is_default) || addresses[0];
      setSelectedAddrId(def.id);
      setForm((f) => ({
        ...f,
        address: def.full_address,
        district: def.district || 'Yazır',
      }));
      if (def.lat && def.lng) {
        setLoc([Number(def.lat), Number(def.lng)]);
      }
    }
  }, [addresses]);

  const handleSelectSavedAddress = (addrId: string) => {
    setSelectedAddrId(addrId);
    if (addrId === 'custom') {
      setForm((f) => ({ ...f, address: '', district: 'Yazır' }));
      setLoc(null);
    } else {
      const selected = addresses.find((a) => a.id === addrId);
      if (selected) {
        setForm((f) => ({
          ...f,
          address: selected.full_address,
          district: selected.district || 'Yazır',
        }));
        if (selected.lat && selected.lng) {
          setLoc([Number(selected.lat), Number(selected.lng)]);
        }
      }
    }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) return;
    if (orderBlocked) {
      toast.error(status.label + '. ' + status.detail);
      return;
    }

    if (needTable) {
      toast.error('Lütfen masanızı seçin');
      return;
    }

    setSubmitting(true);
    try {
      if (dine && !tableToken) {
        // QR olmadan: masa numarası (+ sandalye) ile masa siparişi
        const { data, error } = await supabase.rpc('place_table_order', {
          p_table_number: tableNo,
          p_items: items.map((i) => ({ variant_id: i.variantId, quantity: i.quantity })),
          p_note: form.note || null,
          p_seat: seat,
          p_guest: form.name || null,
        } as any);
        if (error) {
          if (/place_table_order|public_dining_tables/i.test(error.message || '') && /not exist|find the function|schema cache/i.test(error.message || '')) {
            throw new Error('Masa siparişi için sql/50_customer_dinein_table_order.sql çalıştırılmalı.');
          }
          throw error;
        }
        setResult(data as unknown as OrderResult);
        clearCart();
        toast.success('Siparişiniz mutfağa iletildi!');
        return;
      }
      const useExtra = !dine && (!!coupon || pointsToUse > 0);
      const { data, error } = await supabase.rpc('place_order_with_referral', {
        p_customer: {
          name: form.name,
          phone: form.phone,
          address: form.address,
          district: form.district,
          lat: loc?.[0] || null,
          lng: loc?.[1] || null,
          address_title: form.addressTitle,
        },
        p_items: items.map((i) => ({
          variant_id: i.variantId,
          quantity: i.quantity,
        })),
        p_payment: dine ? null : form.payment,
        p_note: (tableToken && seat ? `🪑 Sandalye ${seat}${form.note ? ' · ' + form.note : ''}` : form.note) || null,
        p_table_token: tableToken || null,
        p_save_address: form.saveAddress && user != null,
        p_coupon: useExtra ? (coupon?.code || null) : null,
        p_use_points: useExtra ? pointsToUse : 0,
        p_referral_code: !dine && referral?.is_active ? referral.code : null,
      } as any);

      if (error) throw error;
      setResult(data as unknown as OrderResult);
      clearCart();
      toast.success('Siparişiniz başarıyla alındı!');
    } catch (err: any) {
      toast.error(err.message || 'Sipariş gönderilemedi');
    } finally {
      setSubmitting(false);
    }
  };

  if (result) {
    return (
      <main className="page narrow center">
        <div className="ok-big">✓</div>
        <h1>Siparişiniz Alındı!</h1>
        <p style={{ fontSize: '1.2rem', margin: '0.8rem 0' }}>
          Sipariş No: <b>#{result.order_no}</b> · Toplam: <b>{tl(result.total)}</b>
        </p>
        <p className="muted" style={{ maxWidth: '480px', margin: '0 auto 1.5rem auto' }}>
          {dine ? (
            <>Siparişiniz mutfağa iletildi{(tableNo ?? qrNo) ? <> · <b>Masa {tableNo ?? qrNo}{seat ? ` · Sandalye ${seat}` : ''}</b></> : null}. Afiyet olsun!</>
          ) : (
            <>Siparişiniz mutfağa iletildi ve hazırlanmaya başlandı. Tahmini teslimat süresi{' '}
            <b>{settings?.estimated_delivery_min || 15}–{settings?.estimated_delivery_max || 25} dakika</b>dır.</>
          )}
        </p>
        <div className="os-actions">
          <Link className="btn gold" to={`/takip/${result.order_id}`}>
            Siparişimi Canlı Takip Et
          </Link>
          <a
            className="btn wa-btn"
            target="_blank"
            rel="noreferrer"
            href={waUrl(settings?.whatsapp, `Merhaba, #${result.order_no} numaralı siparişimi verdim. Takip bağlantım: ${window.location.origin}/takip/${result.order_id}`)}
          >
            WhatsApp'tan bildir
          </a>
          <button
            type="button"
            className="btn ghost"
            onClick={() => {
              const link = `${window.location.origin}/takip/${result.order_id}`;
              navigator.clipboard?.writeText(link).then(() => toast.success('Takip bağlantısı kopyalandı'), () => toast.error('Kopyalanamadı'));
            }}
          >
            Takip linkini kopyala
          </button>
          <Link className="btn ghost" to="/">
            Ana Sayfaya Dön
          </Link>
        </div>
        <p className="muted small" style={{ marginTop: '1rem' }}>Bu bağlantıyı saklayın: sipariş durumunu ve kuryenin konumunu istediğiniz zaman görebilirsiniz.</p>
      </main>
    );
  }

  if (items.length === 0) {
    return (
      <main className="page narrow center">
        <h1>Sepetiniz Boş</h1>
        <p className="muted">Tane tane lezzetli pilavlarımızdan dilediğinizi menüden seçebilirsiniz.</p>
        <Link className="btn gold" to="/menu" style={{ marginTop: '1rem' }}>
          Menüye Git
        </Link>
      </main>
    );
  }

  return (
    <main className="page two">
      <section>
        <h1>{dine ? 'Masa Siparişini Tamamla' : 'Siparişi Tamamla'}</h1>

        {/* Sipariş türü seçimi */}
        {!tableToken && mode === null && (
          <div className="mode-pick" role="group" aria-label="Sipariş türü">
            <button type="button" onClick={() => setMode('dine')}>
              <span className="mp-ico" aria-hidden="true">🍽️</span>
              <b>Restoranda yiyeceğim</b>
              <small>Masa numaranızı seçin, adres gerekmez</small>
            </button>
            <button type="button" onClick={() => setMode('delivery')}>
              <span className="mp-ico" aria-hidden="true">🛵</span>
              <b>Eve sipariş edeceğim</b>
              <small>Adrese teslim · ödeme kapıda</small>
            </button>
          </div>
        )}
        {!tableToken && mode !== null && (
          <div className="mode-bar">
            <b>{mode === 'dine' ? '🍽️ Restoranda yiyeceğim' : '🛵 Eve sipariş'}</b>
            <button type="button" className="btn ghost sm" onClick={() => setMode(mode === 'dine' ? 'delivery' : 'dine')}>
              {mode === 'dine' ? 'Eve sipariş ver' : 'Restoranda yiyeceğim'}
            </button>
          </div>
        )}

        {/* Giriş Yapmamış Misafir İçin Önemli Bilgilendirme Uyarısı */}
        {!user && !dine && (
          <div className="note alert-callout" style={{ marginBottom: '1.5rem', lineHeight: '1.6' }}>
            <b>⚠️ Misafir Olarak Sipariş Veriyorsunuz</b>
            <p style={{ margin: '0.3rem 0 0 0', fontSize: '0.92rem' }}>
              Siparişiniz sorunsuz alınacaktır; ancak müşteri girişi yapmadığınız için sipariş geçmişiniz ve adres bilgileriniz kaydedilmez.
              Gelecek siparişlerinizde tekrar adres girmemek ve siparişinizi anlık takip edebilmek için{' '}
              <Link to="/giris">Giriş Yapın</Link> veya <Link to="/kayit">Kayıt Olun</Link>.
            </p>
          </div>
        )}

        {orderBlocked && (
          <div className="note closed-order-note" role="alert">
            <b>{status.label}.</b> {status.detail} Sepetiniz kaydedildi, açıldığımızda sipariş verebilirsiniz.
          </div>
        )}
        {(mode !== null || !!tableToken) && (
        <form onSubmit={submit} className="form">
          {dine && (
            <>
              <DineInPicker tableNo={tableNo} setTableNo={setTableNo} seat={seat} setSeat={setSeat} lockedNo={tableToken ? (qrNo ?? 0) : null} />
              <label>
                <span className="fld-row">
                  Adınız (İsteğe bağlı)
                  <VoiceDictateButton value={form.name} onChange={(v) => setForm((f) => ({ ...f, name: v }))} title="Adınızı sesle yazdırın" />
                </span>
                <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Garson size ismen seslensin" />
              </label>
            </>
          )}
          {!dine && (
            <>
              {/* Kayıtlı Adres Seçimi (Giriş Yapmış Müşteri İçin) */}
              {user && addresses.length > 0 && (
                <div style={{ background: 'var(--surface)', padding: '1rem', borderRadius: '12px', border: '1px solid var(--line)' }}>
                  <b style={{ display: 'block', marginBottom: '0.6rem' }}>📍 Kayıtlı Adreslerinizden Seçin:</b>
                  <div style={{ display: 'grid', gap: '0.5rem' }}>
                    {addresses.map((a) => (
                      <label
                        key={a.id}
                        className="radio"
                        style={{
                          background: selectedAddrId === a.id ? 'var(--card-bg)' : 'transparent',
                          border: `1.5px solid ${selectedAddrId === a.id ? 'var(--gold)' : 'var(--line)'}`,
                          borderRadius: '8px',
                          padding: '0.6rem 0.8rem',
                        }}
                      >
                        <input
                          type="radio"
                          name="addrPick"
                          checked={selectedAddrId === a.id}
                          onChange={() => handleSelectSavedAddress(a.id)}
                        />
                        <div>
                          <b>{a.title}</b> {a.is_default && <span className="small muted">(Varsayılan)</span>}
                          <div className="small muted">{a.full_address} ({a.district || 'Yazır'})</div>
                        </div>
                      </label>
                    ))}
                    <label
                      className="radio"
                      style={{
                        background: selectedAddrId === 'custom' ? 'var(--card-bg)' : 'transparent',
                        border: `1.5px solid ${selectedAddrId === 'custom' ? 'var(--gold)' : 'var(--line)'}`,
                        borderRadius: '8px',
                        padding: '0.6rem 0.8rem',
                      }}
                    >
                      <input
                        type="radio"
                        name="addrPick"
                        checked={selectedAddrId === 'custom'}
                        onChange={() => handleSelectSavedAddress('custom')}
                      />
                      <span>+ Farklı bir adres gir</span>
                    </label>
                  </div>
                </div>
              )}

              <div className="two-col">
                <label>
                  <span className="fld-row">
                    Ad Soyad
                    <VoiceDictateButton value={form.name} onChange={(v) => setForm((f) => ({ ...f, name: v }))} title="Adınızı sesle yazdırın" />
                  </span>
                  <input
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="Adınız ve Soyadınız — veya 🎙️ ile söyleyin"
                  />
                </label>
                <label>
                  <span className="fld-row">
                    Telefon Numarası
                    <VoiceDictateButton
                      value={form.phone}
                      onChange={(v) => setForm((f) => ({ ...f, phone: v }))}
                      onFinalize={(spoken) => { const n = normalizePhone(spoken); if (n) setForm((f) => ({ ...f, phone: n })); }}
                      title="Telefon numaranızı sesle yazdırın"
                    />
                  </span>
                  <input
                    required
                    type="tel"
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    placeholder="05xx xxx xx xx — veya 🎙️ ile söyleyin"
                  />
                </label>
              </div>

              {(selectedAddrId === 'custom' || !user) && (
                <>
                  <label>
                    <span className="fld-row">
                      Mahalle / Semt
                      <VoiceDictateButton value={form.district} onChange={(v) => setForm((f) => ({ ...f, district: v }))} title="Mahallenizi sesle yazdırın" />
                    </span>
                    <input
                      required
                      value={form.district}
                      onChange={(e) => setForm({ ...form, district: e.target.value })}
                      placeholder="Yazır, Bosna Hersek, Kosova..."
                    />
                  </label>
                  <label>
                    <span className="fld-row">
                      Açık Adres (Cadde, Sokak, Bina No, Kat, Daire)
                      <VoiceDictateButton value={form.address} onChange={(v) => setForm((f) => ({ ...f, address: v }))} title="Adresinizi sesle yazdırın" />
                    </span>
                    <textarea
                      required
                      rows={3}
                      value={form.address}
                      onChange={(e) => setForm({ ...form, address: e.target.value })}
                      placeholder="Mahalle, Cadde, Sokak, Bina ve Kapı Numarası — veya 🎙️ ile söyleyin"
                    />
                  </label>
                  <div className="locrow-pick">
                    <b style={{ fontSize: '0.92rem' }}>📍 Konumunuzu haritada işaretleyin</b>
                    <p className="small muted" style={{ margin: '0.15rem 0 0.5rem' }}>
                      Kurye adresinizi daha hızlı bulur. Haritaya dokunun, pini sürükleyin veya adresinizi aratın.
                    </p>
                    <LocationPicker
                      value={loc ? { lat: loc[0], lng: loc[1] } : null}
                      onChange={(p) => setLoc(p ? [p.lat, p.lng] : null)}
                      address={form.address}
                      district={form.district}
                      onAddress={(a) => setForm((f) => ({ ...f, address: a.address, district: a.district || f.district }))}
                      height="260px"
                    />
                  </div>
                  {user && (
                    <div style={{ display: 'flex', gap: '0.8rem', alignItems: 'center' }}>
                      <label className="radio" style={{ margin: 0 }}>
                        <input
                          type="checkbox"
                          checked={form.saveAddress}
                          onChange={(e) => setForm({ ...form, saveAddress: e.target.checked })}
                        />
                        Bu adresi profilime kaydet
                      </label>
                      {form.saveAddress && (
                        <input
                          style={{ width: '130px', padding: '0.4em' }}
                          value={form.addressTitle}
                          onChange={(e) => setForm({ ...form, addressTitle: e.target.value })}
                          placeholder="Adres İsmi (İş)"
                        />
                      )}
                    </div>
                  )}
                </>
              )}
            </>
          )}

          <label>
            <span className="fld-row">
              Sipariş Notu (İsteğe bağlı)
              <VoiceDictateButton value={form.note} onChange={(v) => setForm((f) => ({ ...f, note: v }))} title="Notunuzu sesle yazdırın" />
            </span>
            <input
              value={form.note}
              onChange={(e) => setForm({ ...form, note: e.target.value })}
              placeholder="Örn: Zile basmayın lütfen, acı sos ekleyin — veya 🎙️ ile söyleyin"
            />
          </label>

          {!dine && (
            <fieldset>
              <legend>Ödeme Yöntemi</legend>
              {['cash_on_delivery', 'card_on_delivery', 'iban'].map((m) => (
                <label key={m} className="radio">
                  <input
                    type="radio"
                    name="pay"
                    checked={form.payment === m}
                    onChange={() => setForm({ ...form, payment: m })}
                  />
                  <b>{PAYMENT_METHOD_LABELS[m]}</b>
                </label>
              ))}
              {form.payment === 'iban' && settings?.iban && (
                <div className="note" style={{ marginTop: '0.8rem', fontSize: '0.9rem' }}>
                  <b>IBAN Bilgisi:</b> {settings.iban}
                  {settings.iban_holder && <> · {settings.iban_holder}</>}
                  <br />
                  <span className="small muted">
                    Havale/EFT açıklama kısmına lütfen adınızı yazınız. Ödeme kontrol edilince siparişiniz yola çıkar.
                  </span>
                </div>
              )}
            </fieldset>
          )}

          <button type="submit" className="btn gold" disabled={submitting || orderBlocked} style={{ fontSize: '1.05rem', padding: '0.9em' }}>
            {orderBlocked ? status.label : submitting ? 'Sipariş İletiliyor...' : dine ? `Siparişi Mutfağa Gönder · ${tl(grandTotal)}` : `Siparişi Onayla · ${tl(grandTotal)}`}
          </button>
        </form>
        )}
      </section>

      {/* Sepet Özeti */}
      <aside className="cart">
        <div className="cart-heading-row">
          <h2>Sepetiniz ({items.reduce((sum, item) => sum + item.quantity, 0)} ürün)</h2>
          <button type="button" className="btn ghost sm cart-clear-btn" onClick={emptyCart} disabled={!items.length}>🗑 Sepeti Temizle</button>
        </div>
        {items.length > 0 && (
          <div className="cart-bulk-actions">
            <label className="cart-select-all">
              <input
                type="checkbox"
                checked={items.length > 0 && selectedCartItems.length === items.length}
                onChange={(e) => setSelectedCartKeys(e.target.checked ? items.map((item) => item.key) : [])}
              />
              Tüm satırları seç
            </label>
            <button type="button" className="btn ghost sm" onClick={removeSelectedItems} disabled={!selectedCartItems.length}>
              Seçilenleri kaldır ({selectedCartItems.length})
            </button>
          </div>
        )}
        <div className="cart-items-scroll">
          {items.map((i) => (
            <div key={i.key} className="crow cart-item-row" style={{ alignItems: 'center' }}>
              <input
                className="cart-item-check"
                type="checkbox"
                aria-label={`${i.productName} satırını seç`}
                checked={selectedCartKeys.includes(i.key)}
                onChange={(e) => setSelectedCartKeys((current) => e.target.checked ? [...current, i.key] : current.filter((key) => key !== i.key))}
              />
              <Link className="cart-product-link" to={`/menu/${slugify(i.productName)}?productId=${encodeURIComponent(i.productId)}`} title={`${i.productName} detaylarını görüntüle`}>
                <ProductImage imagePath={i.image_path} emoji={i.emoji} name={i.productName} size="sm" />
                <span>
                  <b>{i.productName}</b>
                  {i.variantName && <span className="small muted">{i.variantName}</span>}
                  <small className="cart-detail-hint">Ürün detayını gör</small>
                </span>
              </Link>
              <QtyStepper
                value={i.quantity}
                chips={[-10, -5, 5, 10]}
                ariaLabel={`${i.productName} adedi`}
                onChange={(n) => changeQty(i.key, n - i.quantity)}
              />
              <div className="cart-line-price" style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '2px', minWidth: '78px' }}>
                {productReferral ? (
                  <>
                    <small style={{ textDecoration: 'line-through', opacity: .6 }}>{tl(i.quantity * i.price)}</small>
                    <b style={{ color: 'var(--success)' }}>{tl(i.quantity * discountedPrice(i.price, referralPercent))}</b>
                    <small style={{ color: 'var(--success)', fontWeight: 700 }}>%{referralPercent} indirim</small>
                    {i.quantity > 1 && <small className="muted">{tl(discountedPrice(i.price, referralPercent))} / adet</small>}
                  </>
                ) : (
                  <b style={{ color: 'var(--gold-ink)' }}>{tl(i.quantity * i.price)}</b>
                )}
              </div>
              <button type="button" className="cart-remove-line" onClick={() => { removeItem(i.key); setSelectedCartKeys((current) => current.filter((key) => key !== i.key)); }} aria-label={`${i.productName} satırını sepetten kaldır`} title="Bu satırı tamamen kaldır">
                <Icon name="trash" size={16} />
              </button>
            </div>
          ))}
        </div>

        {!dine && (
          <div className="coupon-box">
            {coupon ? (
              <div className="coupon-ok">
                <span>🎟️ <b>{coupon.code}</b> uygulandı{coupon.title ? ` · ${coupon.title}` : ''}</span>
                <button type="button" className="linkbtn" onClick={() => { setCoupon(null); setCouponInput(''); }}>Kaldır</button>
              </div>
            ) : (
              <div className="coupon-form">
                <input
                  placeholder="Kupon kodu"
                  value={couponInput}
                  onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), applyCoupon())}
                  aria-label="Kupon kodu"
                />
                <button type="button" className="btn ghost sm" onClick={applyCoupon} disabled={couponBusy || !couponInput.trim()}>
                  {couponBusy ? '…' : 'Uygula'}
                </button>
              </div>
            )}
            <a className="small" href="/kampanyalar" target="_blank" rel="noreferrer">Güncel kampanyaları gör →</a>
          </div>
        )}

        {canUsePoints && (
          <label className="points-box">
            <input type="checkbox" checked={usePoints} onChange={(e) => setUsePoints(e.target.checked)} />
            <span>
              ⭐ <b>{pointsAvail}</b> puanımı kullan <small className="muted">(1 puan = {tl(pointValue)})</small>
              {usePoints && pointsToUse > 0 && <em> −{tl(pointsDiscount)}</em>}
            </span>
          </label>
        )}

        {settings && settings.delivery_fee > 0 && !dine && (
          <div className="crow">
            <span>Teslimat Ücreti</span>
            <span />
            <span>
              {deliveryFee === 0 ? <span style={{ color: 'var(--success)', fontWeight: 700 }}>Ücretsiz</span> : tl(settings.delivery_fee)}
            </span>
          </div>
        )}
        {couponDiscount > 0 && (
          <div className="crow">
            <span>Kupon indirimi</span>
            <span />
            <span style={{ color: 'var(--success)', fontWeight: 700 }}>−{tl(couponDiscount)}</span>
          </div>
        )}
        {pointsDiscount > 0 && (
          <div className="crow">
            <span>Puan indirimi</span>
            <span />
            <span style={{ color: 'var(--success)', fontWeight: 700 }}>−{tl(pointsDiscount)}</span>
          </div>
        )}

        {referral?.is_active && referralDiscount > 0 && (
          <>
            <div className="crow">
              <span>İndirimsiz ürün toplamı</span>
              <span />
              <b>{tl(cartTotal)}</b>
            </div>
            <div className="crow">
              <span>Referans indirimi (%{referral.discount})</span>
              <span />
              <span style={{ color: 'var(--success)', fontWeight: 700 }}>−{tl(referralDiscount)}</span>
            </div>
            <div className="crow">
              <span style={{ fontWeight: 700 }}>İndirimli ürün toplamı</span>
              <span />
              <b style={{ color: 'var(--success)' }}>{tl(Math.max(cartTotal - referralDiscount, 0))}</b>
            </div>
          </>
        )}

        <div className="crow total">
          <span>Genel Toplam</span>
          <b>{tl(grandTotal)}</b>
        </div>
      </aside>
    </main>
  );
}
